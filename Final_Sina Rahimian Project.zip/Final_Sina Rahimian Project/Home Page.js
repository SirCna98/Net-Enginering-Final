<script src="https://kit.fontawesome.com/yourcode.js"></script>
